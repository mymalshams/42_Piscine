/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft.h                                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malshams2 <malshams2@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/25 02:28:04 by malshams2         #+#    #+#             */
/*   Updated: 2021/08/25 02:28:05 by malshams2        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_H
# define FT_H
# include <unistd.h>

long int	add(int nb1, int nb2);
long int	sub(int nb1, int nb2);
long int	divide(int nb1, int nb2);
long int	multiply(int nb1, int nb2);
long int	modulo(int nb1, int nb2);
void		ft_putstr(char *str);
int			ft_strlen(char *str);
void		ft_putnbr(long int nb);
int			ft_atoi(char *str);

#endif
