/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_operations.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malshams2 <malshams2@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/25 02:27:54 by malshams2         #+#    #+#             */
/*   Updated: 2021/08/25 02:27:58 by malshams2        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

long int	add(int nb1, int nb2)
{
	return (nb1 + nb2);
}

long int	sub(int nb1, int nb2)
{
	return (nb1 - nb2);
}

long int	divide(int nb1, int nb2)
{
	return (nb1 / nb2);
}

long int	multiply(int nb1, int nb2)
{
	return (nb1 * nb2);
}

long int	modulo(int nb1, int nb2)
{
	return (nb1 % nb2);
}
