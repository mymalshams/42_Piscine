/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malshams2 <malshams2@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/25 04:39:02 by malshams2         #+#    #+#             */
/*   Updated: 2021/08/25 04:39:03 by malshams2        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_STRNCPY_H
# define FT_STRNCPY_H

char	*ft_str_sized_copy(char *dest, char *src, unsigned int src_size);

#endif
