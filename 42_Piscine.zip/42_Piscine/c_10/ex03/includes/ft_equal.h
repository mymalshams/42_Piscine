/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_equal.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malshams2 <malshams2@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/25 04:40:58 by malshams2         #+#    #+#             */
/*   Updated: 2021/08/25 04:40:58 by malshams2        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_EQUAL_H
# define FT_EQUAL_H

# include <stdbool.h>

bool	ft_is_equal(char *a, char *b, unsigned int size);

#endif
