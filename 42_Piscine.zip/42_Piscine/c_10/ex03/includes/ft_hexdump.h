/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_hexdump.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malshams2 <malshams2@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/25 04:41:09 by malshams2         #+#    #+#             */
/*   Updated: 2021/08/25 04:41:10 by malshams2        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_HEXDUMP_H
# define FT_HEXDUMP_H

# include <stdbool.h>

# include "ft_args_parser.h"

bool	ft_stdin_hexdump(t_options *options);

bool	ft_hexdump(t_options *options, int count);

#endif
