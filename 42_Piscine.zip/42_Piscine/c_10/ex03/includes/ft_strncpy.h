/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: malshams2 <malshams2@student.42.fr>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/25 04:41:13 by malshams2         #+#    #+#             */
/*   Updated: 2021/08/25 04:41:14 by malshams2        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_STRNCPY_H
# define FT_STRNCPY_H

char	*ft_strncpy(char *dest, char *src, unsigned int n);

#endif
